﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebCam
{
 public class Circle
    {
        public double X;
        public double Y;
        public double R;
        public List<Circle> Circles = new List<Circle>();
    }
}
