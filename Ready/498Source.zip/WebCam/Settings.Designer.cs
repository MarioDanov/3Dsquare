﻿namespace WebCam
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cameraPanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.labelcenterDV = new System.Windows.Forms.Label();
            this.labelcenterDS = new System.Windows.Forms.Label();
            this.labelcenterDH = new System.Windows.Forms.Label();
            this.labelCenterV = new System.Windows.Forms.Label();
            this.labelCenterS = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.centerDH = new System.Windows.Forms.HScrollBar();
            this.centerDV = new System.Windows.Forms.HScrollBar();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.centerDS = new System.Windows.Forms.HScrollBar();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.hScrollBar9 = new System.Windows.Forms.HScrollBar();
            this.hScrollBar7 = new System.Windows.Forms.HScrollBar();
            this.hScrollBar4 = new System.Windows.Forms.HScrollBar();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.hScrollBar5 = new System.Windows.Forms.HScrollBar();
            this.hScrollBar8 = new System.Windows.Forms.HScrollBar();
            this.label6 = new System.Windows.Forms.Label();
            this.hScrollBar6 = new System.Windows.Forms.HScrollBar();
            this.label3 = new System.Windows.Forms.Label();
            this.centerV = new System.Windows.Forms.HScrollBar();
            this.label2 = new System.Windows.Forms.Label();
            this.centerS = new System.Windows.Forms.HScrollBar();
            this.labelCenterH = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.centerH = new System.Windows.Forms.HScrollBar();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelCenter = new System.Windows.Forms.Panel();
            this.textBoxColor = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cameraPanel
            // 
            this.cameraPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cameraPanel.Location = new System.Drawing.Point(208, 12);
            this.cameraPanel.Name = "cameraPanel";
            this.cameraPanel.Size = new System.Drawing.Size(617, 725);
            this.cameraPanel.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.labelcenterDV);
            this.panel1.Controls.Add(this.labelcenterDS);
            this.panel1.Controls.Add(this.labelcenterDH);
            this.panel1.Controls.Add(this.labelCenterV);
            this.panel1.Controls.Add(this.labelCenterS);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.centerDH);
            this.panel1.Controls.Add(this.centerDV);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.centerDS);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.hScrollBar9);
            this.panel1.Controls.Add(this.hScrollBar7);
            this.panel1.Controls.Add(this.hScrollBar4);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.hScrollBar5);
            this.panel1.Controls.Add(this.hScrollBar8);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.hScrollBar6);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.centerV);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.centerS);
            this.panel1.Controls.Add(this.labelCenterH);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.centerH);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.textBoxColor);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(216, 725);
            this.panel1.TabIndex = 3;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(140, 352);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(54, 13);
            this.label23.TabIndex = 79;
            this.label23.Text = "Стойност";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(140, 320);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(54, 13);
            this.label22.TabIndex = 78;
            this.label22.Text = "Стойност";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(140, 288);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(54, 13);
            this.label21.TabIndex = 77;
            this.label21.Text = "Стойност";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(140, 256);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(54, 13);
            this.label20.TabIndex = 76;
            this.label20.Text = "Стойност";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(140, 224);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 13);
            this.label19.TabIndex = 75;
            this.label19.Text = "Стойност";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(140, 192);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 13);
            this.label18.TabIndex = 74;
            this.label18.Text = "Стойност";
            // 
            // labelcenterDV
            // 
            this.labelcenterDV.AutoSize = true;
            this.labelcenterDV.ForeColor = System.Drawing.Color.Green;
            this.labelcenterDV.Location = new System.Drawing.Point(140, 160);
            this.labelcenterDV.Name = "labelcenterDV";
            this.labelcenterDV.Size = new System.Drawing.Size(54, 13);
            this.labelcenterDV.TabIndex = 73;
            this.labelcenterDV.Text = "Стойност";
            // 
            // labelcenterDS
            // 
            this.labelcenterDS.AutoSize = true;
            this.labelcenterDS.ForeColor = System.Drawing.Color.Green;
            this.labelcenterDS.Location = new System.Drawing.Point(140, 128);
            this.labelcenterDS.Name = "labelcenterDS";
            this.labelcenterDS.Size = new System.Drawing.Size(54, 13);
            this.labelcenterDS.TabIndex = 72;
            this.labelcenterDS.Text = "Стойност";
            // 
            // labelcenterDH
            // 
            this.labelcenterDH.AutoSize = true;
            this.labelcenterDH.ForeColor = System.Drawing.Color.Green;
            this.labelcenterDH.Location = new System.Drawing.Point(140, 96);
            this.labelcenterDH.Name = "labelcenterDH";
            this.labelcenterDH.Size = new System.Drawing.Size(54, 13);
            this.labelcenterDH.TabIndex = 71;
            this.labelcenterDH.Text = "Стойност";
            // 
            // labelCenterV
            // 
            this.labelCenterV.AutoSize = true;
            this.labelCenterV.ForeColor = System.Drawing.Color.Green;
            this.labelCenterV.Location = new System.Drawing.Point(140, 64);
            this.labelCenterV.Name = "labelCenterV";
            this.labelCenterV.Size = new System.Drawing.Size(54, 13);
            this.labelCenterV.TabIndex = 70;
            this.labelCenterV.Text = "Стойност";
            // 
            // labelCenterS
            // 
            this.labelCenterS.AutoSize = true;
            this.labelCenterS.ForeColor = System.Drawing.Color.Green;
            this.labelCenterS.Location = new System.Drawing.Point(140, 32);
            this.labelCenterS.Name = "labelCenterS";
            this.labelCenterS.Size = new System.Drawing.Size(54, 13);
            this.labelCenterS.TabIndex = 69;
            this.labelCenterS.Text = "Стойност";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Green;
            this.label10.Location = new System.Drawing.Point(3, 160);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 13);
            this.label10.TabIndex = 68;
            this.label10.Text = "Стойност -> Разлика ";
            // 
            // centerDH
            // 
            this.centerDH.LargeChange = 1;
            this.centerDH.Location = new System.Drawing.Point(3, 109);
            this.centerDH.Maximum = 180;
            this.centerDH.Name = "centerDH";
            this.centerDH.Size = new System.Drawing.Size(190, 19);
            this.centerDH.TabIndex = 63;
            this.centerDH.ValueChanged += new System.EventHandler(this.Dif_ScrollBar_ValueChanged);
            // 
            // centerDV
            // 
            this.centerDV.LargeChange = 1;
            this.centerDV.Location = new System.Drawing.Point(6, 173);
            this.centerDV.Maximum = 255;
            this.centerDV.Name = "centerDV";
            this.centerDV.Size = new System.Drawing.Size(190, 19);
            this.centerDV.TabIndex = 67;
            this.centerDV.ValueChanged += new System.EventHandler(this.Dif_ScrollBar_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Green;
            this.label11.Location = new System.Drawing.Point(6, 96);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 13);
            this.label11.TabIndex = 64;
            this.label11.Text = "Oттенък -> Разлика";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Green;
            this.label12.Location = new System.Drawing.Point(6, 128);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(118, 13);
            this.label12.TabIndex = 66;
            this.label12.Text = "Насищане -> Разлика";
            // 
            // centerDS
            // 
            this.centerDS.LargeChange = 1;
            this.centerDS.Location = new System.Drawing.Point(3, 141);
            this.centerDS.Maximum = 255;
            this.centerDS.Name = "centerDS";
            this.centerDS.Size = new System.Drawing.Size(190, 19);
            this.centerDS.TabIndex = 65;
            this.centerDS.ValueChanged += new System.EventHandler(this.Dif_ScrollBar_ValueChanged);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(6, 352);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 13);
            this.label7.TabIndex = 62;
            this.label7.Text = "Стойност -> Разлика ";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(6, 256);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 56;
            this.label4.Text = "Стойност ";
            // 
            // hScrollBar9
            // 
            this.hScrollBar9.LargeChange = 1;
            this.hScrollBar9.Location = new System.Drawing.Point(6, 301);
            this.hScrollBar9.Maximum = 180;
            this.hScrollBar9.Name = "hScrollBar9";
            this.hScrollBar9.Size = new System.Drawing.Size(190, 19);
            this.hScrollBar9.TabIndex = 57;
            this.hScrollBar9.ValueChanged += new System.EventHandler(this.Dif_RScrollBar_ValueChanged);
            // 
            // hScrollBar7
            // 
            this.hScrollBar7.LargeChange = 1;
            this.hScrollBar7.Location = new System.Drawing.Point(5, 365);
            this.hScrollBar7.Maximum = 255;
            this.hScrollBar7.Name = "hScrollBar7";
            this.hScrollBar7.Size = new System.Drawing.Size(190, 19);
            this.hScrollBar7.TabIndex = 61;
            this.hScrollBar7.ValueChanged += new System.EventHandler(this.Dif_RScrollBar_ValueChanged);
            // 
            // hScrollBar4
            // 
            this.hScrollBar4.LargeChange = 1;
            this.hScrollBar4.Location = new System.Drawing.Point(6, 269);
            this.hScrollBar4.Maximum = 255;
            this.hScrollBar4.Name = "hScrollBar4";
            this.hScrollBar4.Size = new System.Drawing.Size(190, 19);
            this.hScrollBar4.TabIndex = 55;
            this.hScrollBar4.ValueChanged += new System.EventHandler(this.RedScrollBar_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(6, 288);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 13);
            this.label9.TabIndex = 58;
            this.label9.Text = "Oттенък -> Разлика";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(6, 224);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 54;
            this.label5.Text = "Насищане";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(6, 320);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 13);
            this.label8.TabIndex = 60;
            this.label8.Text = "Насищане -> Разлика";
            // 
            // hScrollBar5
            // 
            this.hScrollBar5.LargeChange = 1;
            this.hScrollBar5.Location = new System.Drawing.Point(6, 237);
            this.hScrollBar5.Maximum = 255;
            this.hScrollBar5.Name = "hScrollBar5";
            this.hScrollBar5.Size = new System.Drawing.Size(190, 19);
            this.hScrollBar5.TabIndex = 53;
            this.hScrollBar5.ValueChanged += new System.EventHandler(this.RedScrollBar_ValueChanged);
            // 
            // hScrollBar8
            // 
            this.hScrollBar8.LargeChange = 1;
            this.hScrollBar8.Location = new System.Drawing.Point(3, 333);
            this.hScrollBar8.Maximum = 255;
            this.hScrollBar8.Name = "hScrollBar8";
            this.hScrollBar8.Size = new System.Drawing.Size(190, 19);
            this.hScrollBar8.TabIndex = 59;
            this.hScrollBar8.ValueChanged += new System.EventHandler(this.Dif_RScrollBar_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(6, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 52;
            this.label6.Text = "Oттенък";
            // 
            // hScrollBar6
            // 
            this.hScrollBar6.LargeChange = 1;
            this.hScrollBar6.Location = new System.Drawing.Point(6, 205);
            this.hScrollBar6.Maximum = 180;
            this.hScrollBar6.Name = "hScrollBar6";
            this.hScrollBar6.Size = new System.Drawing.Size(190, 19);
            this.hScrollBar6.TabIndex = 51;
            this.hScrollBar6.ValueChanged += new System.EventHandler(this.RedScrollBar_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(6, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "Стойност ";
            // 
            // centerV
            // 
            this.centerV.LargeChange = 1;
            this.centerV.Location = new System.Drawing.Point(3, 77);
            this.centerV.Maximum = 255;
            this.centerV.Name = "centerV";
            this.centerV.Size = new System.Drawing.Size(190, 19);
            this.centerV.TabIndex = 49;
            this.centerV.ValueChanged += new System.EventHandler(this.hScrollBar_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(6, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 48;
            this.label2.Text = "Насищане";
            // 
            // centerS
            // 
            this.centerS.LargeChange = 1;
            this.centerS.Location = new System.Drawing.Point(3, 45);
            this.centerS.Maximum = 255;
            this.centerS.Name = "centerS";
            this.centerS.Size = new System.Drawing.Size(190, 19);
            this.centerS.TabIndex = 47;
            this.centerS.ValueChanged += new System.EventHandler(this.hScrollBar_ValueChanged);
            // 
            // labelCenterH
            // 
            this.labelCenterH.AutoSize = true;
            this.labelCenterH.ForeColor = System.Drawing.Color.Green;
            this.labelCenterH.Location = new System.Drawing.Point(140, 0);
            this.labelCenterH.Name = "labelCenterH";
            this.labelCenterH.Size = new System.Drawing.Size(54, 13);
            this.labelCenterH.TabIndex = 46;
            this.labelCenterH.Text = "Стойност";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 46;
            this.label1.Text = "Oттенък";
            // 
            // centerH
            // 
            this.centerH.LargeChange = 1;
            this.centerH.Location = new System.Drawing.Point(3, 13);
            this.centerH.Maximum = 180;
            this.centerH.Name = "centerH";
            this.centerH.Size = new System.Drawing.Size(190, 19);
            this.centerH.TabIndex = 45;
            this.centerH.ValueChanged += new System.EventHandler(this.hScrollBar_ValueChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.panelCenter);
            this.panel2.Location = new System.Drawing.Point(74, 387);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(64, 64);
            this.panel2.TabIndex = 3;
            // 
            // panelCenter
            // 
            this.panelCenter.BackColor = System.Drawing.Color.OliveDrab;
            this.panelCenter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCenter.Location = new System.Drawing.Point(15, 15);
            this.panelCenter.Name = "panelCenter";
            this.panelCenter.Size = new System.Drawing.Size(32, 32);
            this.panelCenter.TabIndex = 3;
            // 
            // textBoxColor
            // 
            this.textBoxColor.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxColor.BackColor = System.Drawing.SystemColors.InfoText;
            this.textBoxColor.ForeColor = System.Drawing.Color.White;
            this.textBoxColor.Location = new System.Drawing.Point(3, 457);
            this.textBoxColor.Multiline = true;
            this.textBoxColor.Name = "textBoxColor";
            this.textBoxColor.Size = new System.Drawing.Size(210, 265);
            this.textBoxColor.TabIndex = 4;
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 749);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cameraPanel);
            this.Name = "Settings";
            this.Text = "Настройки";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel cameraPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxColor;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.HScrollBar centerDH;
        private System.Windows.Forms.HScrollBar centerDV;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.HScrollBar centerDS;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.HScrollBar hScrollBar9;
        private System.Windows.Forms.HScrollBar hScrollBar7;
        private System.Windows.Forms.HScrollBar hScrollBar4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.HScrollBar hScrollBar5;
        private System.Windows.Forms.HScrollBar hScrollBar8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.HScrollBar hScrollBar6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.HScrollBar centerV;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.HScrollBar centerS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.HScrollBar centerH;
        private System.Windows.Forms.Panel panelCenter;
        private System.Windows.Forms.Label labelCenterH;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label labelcenterDV;
        private System.Windows.Forms.Label labelcenterDS;
        private System.Windows.Forms.Label labelcenterDH;
        private System.Windows.Forms.Label labelCenterV;
        private System.Windows.Forms.Label labelCenterS;
    }
}